﻿namespace HEME_vr1
{
    partial class HEMA_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HEMA_home));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox2 = new WindowsFormsAero.TextBox();
            this.chart_1 = new System.Windows.Forms.TabPage();
            this.cd_SD = new System.Windows.Forms.CheckBox();
            this.grp_analysis_type = new System.Windows.Forms.GroupBox();
            this.rdo_pro_profile = new System.Windows.Forms.RadioButton();
            this.rdo_frq_distribution = new System.Windows.Forms.RadioButton();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.grp_analysis_level = new System.Windows.Forms.GroupBox();
            this.rdo_genic_features = new System.Windows.Forms.RadioButton();
            this.rdo_whole_genome = new System.Windows.Forms.RadioButton();
            this.grp_analysis = new System.Windows.Forms.GroupBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.rdo_start = new System.Windows.Forms.RadioButton();
            this.rdo_stored = new System.Windows.Forms.RadioButton();
            this.btn_run = new System.Windows.Forms.Button();
            this.grp_property = new System.Windows.Forms.GroupBox();
            this.cbo_pro_win = new System.Windows.Forms.ComboBox();
            this.cbo_pro_name = new System.Windows.Forms.ComboBox();
            this.pro_window = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbo_pro_type = new System.Windows.Forms.ComboBox();
            this.grp_context = new System.Windows.Forms.GroupBox();
            this.cbo_bp_flanking = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rdo_right = new System.Windows.Forms.RadioButton();
            this.rdo_centre = new System.Windows.Forms.RadioButton();
            this.rdo_left = new System.Windows.Forms.RadioButton();
            this.grp_features = new System.Windows.Forms.GroupBox();
            this.N_of_feature2 = new System.Windows.Forms.Label();
            this.N_of_feature1 = new System.Windows.Forms.Label();
            this.N2 = new System.Windows.Forms.Label();
            this.N1 = new System.Windows.Forms.Label();
            this.cbo_second_feature_rank = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbo_first_feature_rank = new System.Windows.Forms.ComboBox();
            this.rdo_two_feature = new System.Windows.Forms.RadioButton();
            this.rdo_one_feature = new System.Windows.Forms.RadioButton();
            this.cbo_second_feature = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cbo_first_feature = new System.Windows.Forms.ComboBox();
            this.grp_species = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbo_second_species = new WindowsFormsAero.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rdo_two_species = new System.Windows.Forms.RadioButton();
            this.rdo_one_species = new System.Windows.Forms.RadioButton();
            this.cbo_first_species = new WindowsFormsAero.ComboBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.chart_1.SuspendLayout();
            this.grp_analysis_type.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.grp_analysis_level.SuspendLayout();
            this.grp_analysis.SuspendLayout();
            this.grp_property.SuspendLayout();
            this.grp_context.SuspendLayout();
            this.grp_features.SuspendLayout();
            this.grp_species.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HEME_vr1.Properties.Resources.HEM_logo1;
            this.pictureBox1.Location = new System.Drawing.Point(25, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(244, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.chart_1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(25, 68);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1178, 973);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 38);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1170, 931);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = " Home ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(24, 41);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(1118, 81);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = resources.GetString("textBox2.Text");
            // 
            // chart_1
            // 
            this.chart_1.AutoScroll = true;
            this.chart_1.Controls.Add(this.cd_SD);
            this.chart_1.Controls.Add(this.grp_analysis_type);
            this.chart_1.Controls.Add(this.chart1);
            this.chart_1.Controls.Add(this.grp_analysis_level);
            this.chart_1.Controls.Add(this.grp_analysis);
            this.chart_1.Controls.Add(this.grp_property);
            this.chart_1.Controls.Add(this.grp_context);
            this.chart_1.Controls.Add(this.grp_features);
            this.chart_1.Controls.Add(this.grp_species);
            this.chart_1.Location = new System.Drawing.Point(4, 38);
            this.chart_1.Name = "chart_1";
            this.chart_1.Padding = new System.Windows.Forms.Padding(3);
            this.chart_1.Size = new System.Drawing.Size(1170, 931);
            this.chart_1.TabIndex = 1;
            this.chart_1.Text = " Analysis ";
            this.chart_1.UseVisualStyleBackColor = true;
            // 
            // cd_SD
            // 
            this.cd_SD.AutoSize = true;
            this.cd_SD.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cd_SD.Location = new System.Drawing.Point(856, 392);
            this.cd_SD.Name = "cd_SD";
            this.cd_SD.Size = new System.Drawing.Size(181, 26);
            this.cd_SD.TabIndex = 40;
            this.cd_SD.Text = "Standard deviation";
            this.cd_SD.UseVisualStyleBackColor = true;
            this.cd_SD.CheckedChanged += new System.EventHandler(this.SD_CheckedChanged);
            // 
            // grp_analysis_type
            // 
            this.grp_analysis_type.Controls.Add(this.rdo_pro_profile);
            this.grp_analysis_type.Controls.Add(this.rdo_frq_distribution);
            this.grp_analysis_type.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_analysis_type.Location = new System.Drawing.Point(580, 21);
            this.grp_analysis_type.Margin = new System.Windows.Forms.Padding(4);
            this.grp_analysis_type.Name = "grp_analysis_type";
            this.grp_analysis_type.Padding = new System.Windows.Forms.Padding(4);
            this.grp_analysis_type.Size = new System.Drawing.Size(236, 160);
            this.grp_analysis_type.TabIndex = 39;
            this.grp_analysis_type.TabStop = false;
            this.grp_analysis_type.Text = "Analysis type";
            // 
            // rdo_pro_profile
            // 
            this.rdo_pro_profile.AutoSize = true;
            this.rdo_pro_profile.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_pro_profile.Location = new System.Drawing.Point(21, 95);
            this.rdo_pro_profile.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_pro_profile.Name = "rdo_pro_profile";
            this.rdo_pro_profile.Size = new System.Drawing.Size(158, 26);
            this.rdo_pro_profile.TabIndex = 24;
            this.rdo_pro_profile.TabStop = true;
            this.rdo_pro_profile.Text = "Property profile";
            this.rdo_pro_profile.UseVisualStyleBackColor = true;
            this.rdo_pro_profile.CheckedChanged += new System.EventHandler(this.rb_pro_profile_CheckedChanged);
            // 
            // rdo_frq_distribution
            // 
            this.rdo_frq_distribution.AutoSize = true;
            this.rdo_frq_distribution.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_frq_distribution.Location = new System.Drawing.Point(21, 52);
            this.rdo_frq_distribution.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_frq_distribution.Name = "rdo_frq_distribution";
            this.rdo_frq_distribution.Size = new System.Drawing.Size(209, 26);
            this.rdo_frq_distribution.TabIndex = 25;
            this.rdo_frq_distribution.TabStop = true;
            this.rdo_frq_distribution.Text = "Frequency distribution";
            this.rdo_frq_distribution.UseVisualStyleBackColor = true;
            this.rdo_frq_distribution.CheckedChanged += new System.EventHandler(this.rb_frq_distribution_CheckedChanged);
            // 
            // chart1
            // 
            this.chart1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend1.IsTextAutoFit = false;
            legend1.Name = "Property";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(17, 425);
            this.chart1.Margin = new System.Windows.Forms.Padding(4);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Color = System.Drawing.Color.Blue;
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.Legend = "Property";
            series1.Name = "Property1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.Color = System.Drawing.Color.Red;
            series2.Legend = "Property";
            series2.Name = "Property2";
            series3.BorderColor = System.Drawing.Color.Transparent;
            series3.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Range;
            series3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(135)))), ((int)(((byte)(206)))), ((int)(((byte)(235)))));
            series3.Legend = "Property";
            series3.Name = "SD1";
            series3.ShadowColor = System.Drawing.Color.Transparent;
            series3.YValuesPerPoint = 2;
            series4.BorderColor = System.Drawing.Color.Transparent;
            series4.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Range;
            series4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(255)))), ((int)(((byte)(182)))), ((int)(((byte)(193)))));
            series4.Legend = "Property";
            series4.Name = "SD2";
            series4.ShadowColor = System.Drawing.Color.Transparent;
            series4.YValuesPerPoint = 2;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series5.Color = System.Drawing.Color.Lime;
            series5.Legend = "Property";
            series5.Name = "Property3";
            this.chart1.Series.Add(series1);
            this.chart1.Series.Add(series2);
            this.chart1.Series.Add(series3);
            this.chart1.Series.Add(series4);
            this.chart1.Series.Add(series5);
            this.chart1.Size = new System.Drawing.Size(1103, 476);
            this.chart1.TabIndex = 39;
            this.chart1.Text = "chart1";
            // 
            // grp_analysis_level
            // 
            this.grp_analysis_level.Controls.Add(this.rdo_genic_features);
            this.grp_analysis_level.Controls.Add(this.rdo_whole_genome);
            this.grp_analysis_level.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_analysis_level.Location = new System.Drawing.Point(330, 21);
            this.grp_analysis_level.Margin = new System.Windows.Forms.Padding(4);
            this.grp_analysis_level.Name = "grp_analysis_level";
            this.grp_analysis_level.Padding = new System.Windows.Forms.Padding(4);
            this.grp_analysis_level.Size = new System.Drawing.Size(239, 160);
            this.grp_analysis_level.TabIndex = 38;
            this.grp_analysis_level.TabStop = false;
            this.grp_analysis_level.Text = "Analysis level";
            // 
            // rdo_genic_features
            // 
            this.rdo_genic_features.AutoSize = true;
            this.rdo_genic_features.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_genic_features.Location = new System.Drawing.Point(21, 95);
            this.rdo_genic_features.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_genic_features.Name = "rdo_genic_features";
            this.rdo_genic_features.Size = new System.Drawing.Size(145, 26);
            this.rdo_genic_features.TabIndex = 24;
            this.rdo_genic_features.TabStop = true;
            this.rdo_genic_features.Text = "Genic features";
            this.rdo_genic_features.UseVisualStyleBackColor = true;
            this.rdo_genic_features.CheckedChanged += new System.EventHandler(this.rb_ana_lev2_CheckedChanged);
            // 
            // rdo_whole_genome
            // 
            this.rdo_whole_genome.AutoSize = true;
            this.rdo_whole_genome.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_whole_genome.Location = new System.Drawing.Point(21, 52);
            this.rdo_whole_genome.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_whole_genome.Name = "rdo_whole_genome";
            this.rdo_whole_genome.Size = new System.Drawing.Size(148, 26);
            this.rdo_whole_genome.TabIndex = 25;
            this.rdo_whole_genome.TabStop = true;
            this.rdo_whole_genome.Text = "Whole genome";
            this.rdo_whole_genome.UseVisualStyleBackColor = true;
            this.rdo_whole_genome.CheckedChanged += new System.EventHandler(this.rb_ana_lev1_CheckedChanged);
            // 
            // grp_analysis
            // 
            this.grp_analysis.Controls.Add(this.btn_save);
            this.grp_analysis.Controls.Add(this.rdo_start);
            this.grp_analysis.Controls.Add(this.rdo_stored);
            this.grp_analysis.Controls.Add(this.btn_run);
            this.grp_analysis.Font = new System.Drawing.Font("Times New Roman", 13.8F);
            this.grp_analysis.Location = new System.Drawing.Point(825, 192);
            this.grp_analysis.Margin = new System.Windows.Forms.Padding(4);
            this.grp_analysis.Name = "grp_analysis";
            this.grp_analysis.Padding = new System.Windows.Forms.Padding(4);
            this.grp_analysis.Size = new System.Drawing.Size(295, 180);
            this.grp_analysis.TabIndex = 38;
            this.grp_analysis.TabStop = false;
            this.grp_analysis.Text = "Analysis";
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(161, 119);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(123, 38);
            this.btn_save.TabIndex = 40;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.button2_Click);
            // 
            // rdo_start
            // 
            this.rdo_start.AutoSize = true;
            this.rdo_start.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_start.Location = new System.Drawing.Point(208, 45);
            this.rdo_start.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_start.Name = "rdo_start";
            this.rdo_start.Size = new System.Drawing.Size(68, 26);
            this.rdo_start.TabIndex = 18;
            this.rdo_start.TabStop = true;
            this.rdo_start.Text = "Start";
            this.rdo_start.UseVisualStyleBackColor = true;
            this.rdo_start.CheckedChanged += new System.EventHandler(this.rbt_start_CheckedChanged);
            // 
            // rdo_stored
            // 
            this.rdo_stored.AutoSize = true;
            this.rdo_stored.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_stored.Location = new System.Drawing.Point(55, 46);
            this.rdo_stored.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_stored.Name = "rdo_stored";
            this.rdo_stored.Size = new System.Drawing.Size(83, 26);
            this.rdo_stored.TabIndex = 19;
            this.rdo_stored.TabStop = true;
            this.rdo_stored.Text = "Stored";
            this.rdo_stored.UseVisualStyleBackColor = true;
            this.rdo_stored.CheckedChanged += new System.EventHandler(this.rbt_stored_CheckedChanged);
            // 
            // btn_run
            // 
            this.btn_run.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_run.Location = new System.Drawing.Point(17, 119);
            this.btn_run.Name = "btn_run";
            this.btn_run.Size = new System.Drawing.Size(123, 38);
            this.btn_run.TabIndex = 39;
            this.btn_run.Text = "Run";
            this.btn_run.UseVisualStyleBackColor = true;
            this.btn_run.Click += new System.EventHandler(this.button1_Click);
            // 
            // grp_property
            // 
            this.grp_property.Controls.Add(this.cbo_pro_win);
            this.grp_property.Controls.Add(this.cbo_pro_name);
            this.grp_property.Controls.Add(this.pro_window);
            this.grp_property.Controls.Add(this.label2);
            this.grp_property.Controls.Add(this.label1);
            this.grp_property.Controls.Add(this.cbo_pro_type);
            this.grp_property.Font = new System.Drawing.Font("Times New Roman", 13.8F);
            this.grp_property.Location = new System.Drawing.Point(825, 21);
            this.grp_property.Margin = new System.Windows.Forms.Padding(4);
            this.grp_property.Name = "grp_property";
            this.grp_property.Padding = new System.Windows.Forms.Padding(4);
            this.grp_property.Size = new System.Drawing.Size(295, 160);
            this.grp_property.TabIndex = 37;
            this.grp_property.TabStop = false;
            this.grp_property.Text = "Property";
            // 
            // cbo_pro_win
            // 
            this.cbo_pro_win.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_pro_win.FormattingEnabled = true;
            this.cbo_pro_win.Items.AddRange(new object[] {
            "11",
            "33",
            "101"});
            this.cbo_pro_win.Location = new System.Drawing.Point(116, 113);
            this.cbo_pro_win.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_pro_win.Name = "cbo_pro_win";
            this.cbo_pro_win.Size = new System.Drawing.Size(150, 30);
            this.cbo_pro_win.TabIndex = 26;
            this.cbo_pro_win.Tag = "..";
            // 
            // cbo_pro_name
            // 
            this.cbo_pro_name.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_pro_name.FormattingEnabled = true;
            this.cbo_pro_name.Items.AddRange(new object[] {
            "GC content"});
            this.cbo_pro_name.Location = new System.Drawing.Point(116, 71);
            this.cbo_pro_name.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_pro_name.Name = "cbo_pro_name";
            this.cbo_pro_name.Size = new System.Drawing.Size(149, 30);
            this.cbo_pro_name.TabIndex = 25;
            // 
            // pro_window
            // 
            this.pro_window.AutoSize = true;
            this.pro_window.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pro_window.Location = new System.Drawing.Point(27, 120);
            this.pro_window.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pro_window.Name = "pro_window";
            this.pro_window.Size = new System.Drawing.Size(73, 21);
            this.pro_window.TabIndex = 24;
            this.pro_window.Text = "Window";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 80);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 21);
            this.label2.TabIndex = 23;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 21);
            this.label1.TabIndex = 22;
            this.label1.Text = "Type";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cbo_pro_type
            // 
            this.cbo_pro_type.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_pro_type.FormattingEnabled = true;
            this.cbo_pro_type.Items.AddRange(new object[] {
            "Dinucleotide"});
            this.cbo_pro_type.Location = new System.Drawing.Point(116, 29);
            this.cbo_pro_type.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_pro_type.Name = "cbo_pro_type";
            this.cbo_pro_type.Size = new System.Drawing.Size(150, 30);
            this.cbo_pro_type.TabIndex = 4;
            // 
            // grp_context
            // 
            this.grp_context.Controls.Add(this.cbo_bp_flanking);
            this.grp_context.Controls.Add(this.label4);
            this.grp_context.Controls.Add(this.rdo_right);
            this.grp_context.Controls.Add(this.rdo_centre);
            this.grp_context.Controls.Add(this.rdo_left);
            this.grp_context.Font = new System.Drawing.Font("Times New Roman", 13.8F);
            this.grp_context.Location = new System.Drawing.Point(520, 192);
            this.grp_context.Margin = new System.Windows.Forms.Padding(4);
            this.grp_context.Name = "grp_context";
            this.grp_context.Padding = new System.Windows.Forms.Padding(4);
            this.grp_context.Size = new System.Drawing.Size(298, 180);
            this.grp_context.TabIndex = 36;
            this.grp_context.TabStop = false;
            this.grp_context.Text = "Context";
            // 
            // cbo_bp_flanking
            // 
            this.cbo_bp_flanking.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_bp_flanking.FormattingEnabled = true;
            this.cbo_bp_flanking.Items.AddRange(new object[] {
            "100",
            "200",
            "300",
            "400",
            "500"});
            this.cbo_bp_flanking.Location = new System.Drawing.Point(88, 95);
            this.cbo_bp_flanking.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_bp_flanking.Name = "cbo_bp_flanking";
            this.cbo_bp_flanking.Size = new System.Drawing.Size(73, 30);
            this.cbo_bp_flanking.TabIndex = 20;
            this.cbo_bp_flanking.SelectedIndexChanged += new System.EventHandler(this.bp_flanking_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(169, 100);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 19);
            this.label4.TabIndex = 12;
            this.label4.Text = "bp flanking";
            // 
            // rdo_right
            // 
            this.rdo_right.AutoSize = true;
            this.rdo_right.Font = new System.Drawing.Font("Times New Roman", 10.8F);
            this.rdo_right.Location = new System.Drawing.Point(196, 46);
            this.rdo_right.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_right.Name = "rdo_right";
            this.rdo_right.Size = new System.Drawing.Size(64, 25);
            this.rdo_right.TabIndex = 11;
            this.rdo_right.TabStop = true;
            this.rdo_right.Text = "right";
            this.rdo_right.UseVisualStyleBackColor = true;
            this.rdo_right.CheckedChanged += new System.EventHandler(this.rb3_CheckedChanged);
            // 
            // rdo_centre
            // 
            this.rdo_centre.AutoSize = true;
            this.rdo_centre.Font = new System.Drawing.Font("Times New Roman", 10.8F);
            this.rdo_centre.Location = new System.Drawing.Point(96, 46);
            this.rdo_centre.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_centre.Name = "rdo_centre";
            this.rdo_centre.Size = new System.Drawing.Size(76, 25);
            this.rdo_centre.TabIndex = 10;
            this.rdo_centre.TabStop = true;
            this.rdo_centre.Text = "centre";
            this.rdo_centre.UseVisualStyleBackColor = true;
            this.rdo_centre.CheckedChanged += new System.EventHandler(this.rb2_CheckedChanged);
            // 
            // rdo_left
            // 
            this.rdo_left.AutoSize = true;
            this.rdo_left.Font = new System.Drawing.Font("Times New Roman", 10.8F);
            this.rdo_left.Location = new System.Drawing.Point(23, 46);
            this.rdo_left.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_left.Name = "rdo_left";
            this.rdo_left.Size = new System.Drawing.Size(54, 25);
            this.rdo_left.TabIndex = 9;
            this.rdo_left.TabStop = true;
            this.rdo_left.Text = "left";
            this.rdo_left.UseVisualStyleBackColor = true;
            this.rdo_left.CheckedChanged += new System.EventHandler(this.rb1_CheckedChanged);
            // 
            // grp_features
            // 
            this.grp_features.Controls.Add(this.N_of_feature2);
            this.grp_features.Controls.Add(this.N_of_feature1);
            this.grp_features.Controls.Add(this.N2);
            this.grp_features.Controls.Add(this.N1);
            this.grp_features.Controls.Add(this.cbo_second_feature_rank);
            this.grp_features.Controls.Add(this.label5);
            this.grp_features.Controls.Add(this.label10);
            this.grp_features.Controls.Add(this.cbo_first_feature_rank);
            this.grp_features.Controls.Add(this.rdo_two_feature);
            this.grp_features.Controls.Add(this.rdo_one_feature);
            this.grp_features.Controls.Add(this.cbo_second_feature);
            this.grp_features.Controls.Add(this.label9);
            this.grp_features.Controls.Add(this.label8);
            this.grp_features.Controls.Add(this.cbo_first_feature);
            this.grp_features.Font = new System.Drawing.Font("Times New Roman", 13.8F);
            this.grp_features.Location = new System.Drawing.Point(15, 192);
            this.grp_features.Margin = new System.Windows.Forms.Padding(4);
            this.grp_features.Name = "grp_features";
            this.grp_features.Padding = new System.Windows.Forms.Padding(4);
            this.grp_features.Size = new System.Drawing.Size(497, 180);
            this.grp_features.TabIndex = 35;
            this.grp_features.TabStop = false;
            this.grp_features.Text = "Features";
            // 
            // N_of_feature2
            // 
            this.N_of_feature2.AutoSize = true;
            this.N_of_feature2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N_of_feature2.Location = new System.Drawing.Point(413, 125);
            this.N_of_feature2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.N_of_feature2.Name = "N_of_feature2";
            this.N_of_feature2.Size = new System.Drawing.Size(0, 21);
            this.N_of_feature2.TabIndex = 25;
            // 
            // N_of_feature1
            // 
            this.N_of_feature1.AutoSize = true;
            this.N_of_feature1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N_of_feature1.Location = new System.Drawing.Point(413, 75);
            this.N_of_feature1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.N_of_feature1.Name = "N_of_feature1";
            this.N_of_feature1.Size = new System.Drawing.Size(0, 21);
            this.N_of_feature1.TabIndex = 24;
            // 
            // N2
            // 
            this.N2.AutoSize = true;
            this.N2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N2.Location = new System.Drawing.Point(385, 131);
            this.N2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.N2.Name = "N2";
            this.N2.Size = new System.Drawing.Size(34, 21);
            this.N2.TabIndex = 23;
            this.N2.Text = "N=";
            // 
            // N1
            // 
            this.N1.AutoSize = true;
            this.N1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N1.Location = new System.Drawing.Point(386, 76);
            this.N1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.N1.Name = "N1";
            this.N1.Size = new System.Drawing.Size(34, 21);
            this.N1.TabIndex = 22;
            this.N1.Text = "N=";
            // 
            // cbo_second_feature_rank
            // 
            this.cbo_second_feature_rank.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_second_feature_rank.FormattingEnabled = true;
            this.cbo_second_feature_rank.Location = new System.Drawing.Point(309, 125);
            this.cbo_second_feature_rank.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_second_feature_rank.Name = "cbo_second_feature_rank";
            this.cbo_second_feature_rank.Size = new System.Drawing.Size(73, 30);
            this.cbo_second_feature_rank.TabIndex = 18;
            this.cbo_second_feature_rank.SelectedIndexChanged += new System.EventHandler(this.sec_cbx_rank_SelectedIndexChanged);
            this.cbo_second_feature_rank.SelectionChangeCommitted += new System.EventHandler(this.cbo_second_feature_rank_SelectionChangeCommitted);
            this.cbo_second_feature_rank.Click += new System.EventHandler(this.sec_cbx_rank_Click);
            // 
            // label5
            // 
            this.label5.AllowDrop = true;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(255, 129);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 21);
            this.label5.TabIndex = 20;
            this.label5.Text = "Rank";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(255, 80);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 21);
            this.label10.TabIndex = 21;
            this.label10.Text = "Rank";
            // 
            // cbo_first_feature_rank
            // 
            this.cbo_first_feature_rank.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_first_feature_rank.FormattingEnabled = true;
            this.cbo_first_feature_rank.Location = new System.Drawing.Point(309, 71);
            this.cbo_first_feature_rank.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_first_feature_rank.Name = "cbo_first_feature_rank";
            this.cbo_first_feature_rank.Size = new System.Drawing.Size(73, 30);
            this.cbo_first_feature_rank.TabIndex = 19;
            this.cbo_first_feature_rank.SelectedIndexChanged += new System.EventHandler(this.fir_cbx_rank_SelectedIndexChanged);
            this.cbo_first_feature_rank.SelectionChangeCommitted += new System.EventHandler(this.cbo_first_feature_rank_SelectionChangeCommitted);
            this.cbo_first_feature_rank.Click += new System.EventHandler(this.fir_cbx_rank_Click);
            // 
            // rdo_two_feature
            // 
            this.rdo_two_feature.AutoSize = true;
            this.rdo_two_feature.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_two_feature.Location = new System.Drawing.Point(212, 26);
            this.rdo_two_feature.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_two_feature.Name = "rdo_two_feature";
            this.rdo_two_feature.Size = new System.Drawing.Size(134, 26);
            this.rdo_two_feature.TabIndex = 16;
            this.rdo_two_feature.TabStop = true;
            this.rdo_two_feature.Text = "Two features";
            this.rdo_two_feature.UseVisualStyleBackColor = true;
            this.rdo_two_feature.CheckedChanged += new System.EventHandler(this.rbt_two_feature_CheckedChanged);
            // 
            // rdo_one_feature
            // 
            this.rdo_one_feature.AutoSize = true;
            this.rdo_one_feature.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_one_feature.Location = new System.Drawing.Point(32, 26);
            this.rdo_one_feature.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_one_feature.Name = "rdo_one_feature";
            this.rdo_one_feature.Size = new System.Drawing.Size(122, 26);
            this.rdo_one_feature.TabIndex = 17;
            this.rdo_one_feature.TabStop = true;
            this.rdo_one_feature.Text = "One feature";
            this.rdo_one_feature.UseVisualStyleBackColor = true;
            this.rdo_one_feature.CheckedChanged += new System.EventHandler(this.rbt_one_feature_CheckedChanged);
            // 
            // cbo_second_feature
            // 
            this.cbo_second_feature.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_second_feature.FormattingEnabled = true;
            this.cbo_second_feature.Items.AddRange(new object[] {
            "Exon",
            "Intron",
            "5\'UTR Exon",
            "5\'UTR Intron",
            "3\'UTR Exon",
            "3\'UTR Intron"});
            this.cbo_second_feature.Location = new System.Drawing.Point(94, 125);
            this.cbo_second_feature.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_second_feature.Name = "cbo_second_feature";
            this.cbo_second_feature.Size = new System.Drawing.Size(135, 30);
            this.cbo_second_feature.TabIndex = 4;
            this.cbo_second_feature.SelectedIndexChanged += new System.EventHandler(this.cmb_feature2_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AllowDrop = true;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 129);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 21);
            this.label9.TabIndex = 9;
            this.label9.Text = "Feature B";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 76);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 21);
            this.label8.TabIndex = 9;
            this.label8.Text = "Feature A";
            // 
            // cbo_first_feature
            // 
            this.cbo_first_feature.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbo_first_feature.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.cbo_first_feature.FormattingEnabled = true;
            this.cbo_first_feature.Items.AddRange(new object[] {
            "Exon",
            "Intron",
            "5\'UTR Exon",
            "5\'UTR Intron",
            "3\'UTR Exon",
            "3\'UTR Intron"});
            this.cbo_first_feature.Location = new System.Drawing.Point(94, 72);
            this.cbo_first_feature.Margin = new System.Windows.Forms.Padding(4);
            this.cbo_first_feature.Name = "cbo_first_feature";
            this.cbo_first_feature.Size = new System.Drawing.Size(135, 30);
            this.cbo_first_feature.TabIndex = 4;
            this.cbo_first_feature.SelectedIndexChanged += new System.EventHandler(this.cmb_feature1_SelectedIndexChanged);
            // 
            // grp_species
            // 
            this.grp_species.Controls.Add(this.label3);
            this.grp_species.Controls.Add(this.cbo_second_species);
            this.grp_species.Controls.Add(this.label6);
            this.grp_species.Controls.Add(this.rdo_two_species);
            this.grp_species.Controls.Add(this.rdo_one_species);
            this.grp_species.Controls.Add(this.cbo_first_species);
            this.grp_species.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_species.Location = new System.Drawing.Point(15, 21);
            this.grp_species.Name = "grp_species";
            this.grp_species.Size = new System.Drawing.Size(305, 160);
            this.grp_species.TabIndex = 0;
            this.grp_species.TabStop = false;
            this.grp_species.Text = "Species";
            // 
            // label3
            // 
            this.label3.AllowDrop = true;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 114);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 21);
            this.label3.TabIndex = 22;
            this.label3.Text = "Seccond";
            // 
            // cbo_second_species
            // 
            this.cbo_second_species.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbo_second_species.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbo_second_species.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic);
            this.cbo_second_species.FormattingEnabled = true;
            this.cbo_second_species.Items.AddRange(new object[] {
            "A. thaliana",
            "B. rapa",
            "B. oleracea"});
            this.cbo_second_species.Location = new System.Drawing.Point(108, 111);
            this.cbo_second_species.Name = "cbo_second_species";
            this.cbo_second_species.Size = new System.Drawing.Size(157, 30);
            this.cbo_second_species.TabIndex = 24;
            this.cbo_second_species.SelectedValueChanged += new System.EventHandler(this.cmb_second_species_SelectedValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 64);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 21);
            this.label6.TabIndex = 23;
            this.label6.Text = "First";
            // 
            // rdo_two_species
            // 
            this.rdo_two_species.AutoSize = true;
            this.rdo_two_species.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_two_species.Location = new System.Drawing.Point(169, 29);
            this.rdo_two_species.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_two_species.Name = "rdo_two_species";
            this.rdo_two_species.Size = new System.Drawing.Size(131, 26);
            this.rdo_two_species.TabIndex = 22;
            this.rdo_two_species.TabStop = true;
            this.rdo_two_species.Text = "Two species";
            this.rdo_two_species.UseVisualStyleBackColor = true;
            this.rdo_two_species.CheckedChanged += new System.EventHandler(this.two_species_CheckedChanged);
            // 
            // rdo_one_species
            // 
            this.rdo_one_species.AutoSize = true;
            this.rdo_one_species.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_one_species.Location = new System.Drawing.Point(17, 29);
            this.rdo_one_species.Margin = new System.Windows.Forms.Padding(4);
            this.rdo_one_species.Name = "rdo_one_species";
            this.rdo_one_species.Size = new System.Drawing.Size(127, 26);
            this.rdo_one_species.TabIndex = 23;
            this.rdo_one_species.TabStop = true;
            this.rdo_one_species.Text = "One species";
            this.rdo_one_species.UseVisualStyleBackColor = true;
            this.rdo_one_species.CheckedChanged += new System.EventHandler(this.one_species_CheckedChanged);
            // 
            // cbo_first_species
            // 
            this.cbo_first_species.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbo_first_species.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbo_first_species.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic);
            this.cbo_first_species.FormattingEnabled = true;
            this.cbo_first_species.Items.AddRange(new object[] {
            "A. thaliana",
            "B. rapa",
            "B. oleracea"});
            this.cbo_first_species.Location = new System.Drawing.Point(108, 62);
            this.cbo_first_species.Name = "cbo_first_species";
            this.cbo_first_species.Size = new System.Drawing.Size(157, 30);
            this.cbo_first_species.TabIndex = 1;
            this.cbo_first_species.SelectedValueChanged += new System.EventHandler(this.cmb_first_species_SelectedValueChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 38);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1170, 931);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = " Contact us ";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // HEMA_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1234, 1055);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.pictureBox1);
            this.MinimizeBox = false;
            this.Name = "HEMA_home";
            this.Load += new System.EventHandler(this.HEMA_home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.chart_1.ResumeLayout(false);
            this.chart_1.PerformLayout();
            this.grp_analysis_type.ResumeLayout(false);
            this.grp_analysis_type.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.grp_analysis_level.ResumeLayout(false);
            this.grp_analysis_level.PerformLayout();
            this.grp_analysis.ResumeLayout(false);
            this.grp_analysis.PerformLayout();
            this.grp_property.ResumeLayout(false);
            this.grp_property.PerformLayout();
            this.grp_context.ResumeLayout(false);
            this.grp_context.PerformLayout();
            this.grp_features.ResumeLayout(false);
            this.grp_features.PerformLayout();
            this.grp_species.ResumeLayout(false);
            this.grp_species.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage chart_1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.GroupBox grp_species;
        private System.Windows.Forms.GroupBox grp_property;
        private System.Windows.Forms.ComboBox cbo_pro_type;
        private System.Windows.Forms.GroupBox grp_context;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdo_right;
        private System.Windows.Forms.RadioButton rdo_centre;
        private System.Windows.Forms.RadioButton rdo_left;
        private System.Windows.Forms.GroupBox grp_features;
        private System.Windows.Forms.ComboBox cbo_second_feature_rank;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbo_first_feature_rank;
        private System.Windows.Forms.RadioButton rdo_two_feature;
        private System.Windows.Forms.RadioButton rdo_one_feature;
        private System.Windows.Forms.ComboBox cbo_second_feature;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbo_first_feature;
        private System.Windows.Forms.GroupBox grp_analysis_level;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbo_pro_win;
        private System.Windows.Forms.ComboBox cbo_pro_name;
        private System.Windows.Forms.Label pro_window;
        private System.Windows.Forms.Button btn_run;
        private System.Windows.Forms.RadioButton rdo_genic_features;
        private System.Windows.Forms.RadioButton rdo_whole_genome;
        private System.Windows.Forms.ComboBox cbo_bp_flanking;
        private System.Windows.Forms.GroupBox grp_analysis;
        private System.Windows.Forms.RadioButton rdo_start;
        private System.Windows.Forms.RadioButton rdo_stored;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button btn_save;
        private WindowsFormsAero.TextBox textBox2;
        private WindowsFormsAero.ComboBox cbo_first_species;
        private WindowsFormsAero.ComboBox cbo_second_species;
        private System.Windows.Forms.RadioButton rdo_two_species;
        private System.Windows.Forms.RadioButton rdo_one_species;
        private System.Windows.Forms.GroupBox grp_analysis_type;
        private System.Windows.Forms.RadioButton rdo_pro_profile;
        private System.Windows.Forms.RadioButton rdo_frq_distribution;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox cd_SD;
        private System.Windows.Forms.Label N1;
        private System.Windows.Forms.Label N2;
        private System.Windows.Forms.Label N_of_feature2;
        private System.Windows.Forms.Label N_of_feature1;
    }
}

