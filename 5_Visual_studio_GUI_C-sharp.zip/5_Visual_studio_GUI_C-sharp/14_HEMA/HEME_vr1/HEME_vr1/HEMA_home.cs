﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace HEME_vr1
{
    public partial class HEMA_home : Form
    {
        DataTable tb_rank1 = new DataTable();
        DataTable tb_rank2 = new DataTable();
        DataTable tb_pro1_values = new DataTable();
        DataTable tb_pro1_SD_values = new DataTable();
        DataTable tb_pro2_values = new DataTable();
        DataTable tb_pro2_SD_values = new DataTable();
        DataTable allfeature1 = new DataTable();
        DataTable ValueofFeature1 = new DataTable();




        string feature_id1, feature_id2, query_rank1, query_rank2, query_p1, query_p2, query_SD, query_SD2,context, query_all_feature1, seq_region_id;

        Double[] meanValuesPro1 = new Double[1005];
        Double[] meanValuesPro2 = new Double[1001];

        Double[,] GCarray;
        Double[] gcAVGarray;
        Double[] SDarray,gcSDarray;

        int numberOfFeature1;

        int left = 0, right = 0, centre = 0, center = 0, strand = 0,h=0;/*, stop = 0;*/
        string start, end/*, strand*/;
        Double SD;




        //show value in chart1 by using mouse
        Point? prevPosition = null;
        ToolTip tooltip = new ToolTip();

        void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            var pos = e.Location;
            if (prevPosition.HasValue && pos == prevPosition.Value)
                return;
            tooltip.RemoveAll();
            prevPosition = pos;
            var results = chart1.HitTest(pos.X, pos.Y, false,
                                            ChartElementType.DataPoint);
            foreach (var result in results)
            {
                if (result.ChartElementType == ChartElementType.DataPoint)
                {
                    var prop = result.Object as DataPoint;
                    if (prop != null)
                    {
                        var pointXPixel = result.ChartArea.AxisX.ValueToPixelPosition(prop.XValue);
                        var pointYPixel = result.ChartArea.AxisY.ValueToPixelPosition(prop.YValues[0]);

                        // check if the cursor is really close to the point (2 pixels around the point)
                        if (Math.Abs(pos.X - pointXPixel) < 2 &&
                            Math.Abs(pos.Y - pointYPixel) < 2)
                        {
                            tooltip.Show("X=" + prop.XValue + ", Y=" + prop.YValues[0], this.chart1,
                                            pos.X, pos.Y - 15);
                        }
                    }
                }
            }
        }



        public DataTable runQuery(string query)
        {
            using (MySqlConnection conn = new MySqlConnection())
            {
                conn.ConnectionString = "server=yourserver:user id=ensembl;Password=yourpassw;persistsecurityinfo=True;database=HEMA_arabidopsis_thaliana_core_40_93_11";
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                DataTable tb = new DataTable();
                tb.Load(cmd.ExecuteReader());
                conn.Close();
                return tb;
            }

        }

        //public int[] rowWiseAvg(int[,] inputArray)
        //{
        //    int rows = inputArray.GetLength(0);
        //    int cols = inputArray.GetLength(1);
        //    //MessageBox.Show(rows.ToString());
        //    //MessageBox.Show(cols.ToString());
        //    int[] array = new int[inputArray.GetLength(1)];
        //    for (int i = 0; i < cols; i++)
        //    {
        //        int rowAvg = 0;
        //        for (int x = 0; x < rows; x++)
        //        {
        //            rowAvg += inputArray[x, i];
        //            //MessageBox.Show(inputArray[x, i].ToString());
        //            //MessageBox.Show(rowAvg.ToString());
        //        }
        //        //MessageBox.Show(rowAvg.ToString());
        //        //MessageBox.Show(rows.ToString());
        //        rowAvg = rowAvg / rows;
        //        array[i] = rowAvg;
        //    }
        //    return array;
        //}



        //private Double[] getStandardDeviation(Double[,] inputArray)
        //{
        //    int rows = inputArray.GetLength(0);
        //    int cols = inputArray.GetLength(1);
        //    Double[] array = new Double[inputArray.GetLength(1)];
        //    for (int i = 0; i < cols; i++)
        //    {
        //        Double sumOfDerivation = 0;
        //        //MessageBox.Show(rowAvg.ToString());
        //        for (int x = 0; x < rows; x++)
        //        {
        //            //MessageBox.Show(inputArray[x, i].ToString());
        //            sumOfDerivation += inputArray[x, i];
        //        }
        //        sumOfDerivation = sumOfDerivation / rows;
        //        //MessageBox.Show(rowAvg.ToString());
        //        array[i] = sumOfDerivation;
        //    }
        //    return array;

        //    //double average = doubleList.Average();
        //    //double sumOfDerivation = 0;
        //    //foreach (double value in doubleList)
        //    //{
        //    //    sumOfDerivation += (value) * (value);
        //    //}
        //    //double sumOfDerivationAverage = sumOfDerivation / doubleList.Count;
        //    //return Math.Sqrt(sumOfDerivationAverage - (average * average));
        //}

        private Double getStandardDeviation(Double[] inputArray)
        {
            Double average = inputArray.Average();
            Double sumOfSquaresOfDifferences = inputArray.Select(val => (val - average) * (val - average)).Sum();
            Double sd = Math.Sqrt(sumOfSquaresOfDifferences / inputArray.Length);
            //MessageBox.Show(sd.ToString());
            return sd;
        }

        private Double[] calculateStandardDeviation(Double[,] inputArray)
        {
            MessageBox.Show("within SD");
            int rows = inputArray.GetLength(0);
            int cols = inputArray.GetLength(1);
            Double[] array = new Double[inputArray.GetLength(1)];
            for (int i = 0; i < cols; i++)
            {

                //MessageBox.Show(rowAvg.ToString());
                for (int x = 0; x < rows; x++)
                {
                    //MessageBox.Show(inputArray[x, i].ToString());
                    array[x] = inputArray[x, i];
                    //MessageBox.Show(array[x].ToString());
                }
                //getStandardDeviation(array);
                //MessageBox.Show(rowAvg.ToString());
                gcSDarray[i] = getStandardDeviation(array);
                //MessageBox.Show(gcSDarray[i].ToString());
                //gcSDarray = getStandardDeviation();
            }
            return gcSDarray;

        }


        public Double[] rowWiseAvg(Double[,] inputArray)
        {
            MessageBox.Show("within avg");
            int rows = inputArray.GetLength(0);
            int cols = inputArray.GetLength(1);
            //MessageBox.Show(rows.ToString());
            //MessageBox.Show(cols.ToString());

            Double[] array = new Double[inputArray.GetLength(1)];
            for (int i = 0; i < cols; i++)
            {
                Double rowAvg = 0;
                //MessageBox.Show(rowAvg.ToString());
                for (int x = 0; x < rows; x++)
                {
                    //MessageBox.Show(inputArray[x, i].ToString());
                    rowAvg += inputArray[x, i];
                }
                rowAvg = rowAvg / rows;
                //MessageBox.Show(rowAvg.ToString());
                array[i] = rowAvg;
                //gcSDarray = getStandardDeviation();
            }
            return array;
        }

        static public int runQueryScalarValue(string query)
        {
            //MessageBox.Show("runQueryScalarValue");
            
            using (MySqlConnection conn = new MySqlConnection())
            {
                conn.ConnectionString = "server=yourserver:user id=ensembl;Password=yourpassw;persistsecurityinfo=True;database=HEMA_arabidopsis_thaliana_core_40_93_11";
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                //count= (Int32)cmd.ExecuteScalar();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                //MessageBox.Show(count.ToString());
                conn.Close();
                return count;
            }
        }


        public DataTable ReverseRowsInDataTable(DataTable inputTable)
        {
            DataTable outputTable = inputTable.Clone();

            for (int i = inputTable.Rows.Count - 1; i >= 0; i--)
            {
                outputTable.ImportRow(inputTable.Rows[i]);
            }

            return outputTable;
        }

        public void/*DataTable*/ centre_right_left(string start, string end,string seq_region_id, int bp, int strand)
        {

            string query = "SELECT srpbv.value FROM HEMA_arabidopsis_thaliana_core_40_93_11.seq_region_pos_attrib_value srpbv, " +
            "HEMA_arabidopsis_thaliana_core_40_93_11.seq_region_pos srp WHERE srp.seq_region_pos_id = srpbv.seq_region_pos_id "+
            " and srp.seq_region_position between " + start + " and " + end + " and "+
            " srpbv.attrib_analysis_id  = 10004 and  srp.seq_region_id = " + seq_region_id + ";";
            //MessageBox.Show(query);
            ValueofFeature1 = runQuery(query);


            if (Convert.ToInt32(strand) == -1)
            {
                ValueofFeature1 = ReverseRowsInDataTable(ValueofFeature1);
            }
            int c = -(bp);
            int i = 0;
            
            

            //chart1.ChartAreas["ChartArea1"].AxisY.Maximum = 60;

            foreach (DataRow row in ValueofFeature1.Rows)
            {
                //MessageBox.Show(i.ToString());
                chart1.Series["Property1"].Points.AddXY(c, Convert.ToDouble(row[0]));
                GCarray[h, i] = Convert.ToInt32(row[0]);
                //MessageBox.Show((row[0]).ToString());
                //MessageBox.Show(GCarray[h - 1, i].ToString());
                i++; 
                c++;
                //this.chart1.Update();
            }
            h++;

            this.chart1.Update();
            this.chart1.Series["Property1"].Points.Clear();


            //return ValueofFeature1;


        }

        //public DataTable centre_right_left(string start, string end, string seq_region_id)
        //{

        //    return ValueofFeature1;

        //}

        //public void start_left()
        //{

        //}
        public void Unselect_feature()
        {
            cbo_first_feature.SelectedIndex = -1;
            cbo_second_feature.SelectedIndex = -1;
            cbo_first_feature_rank.SelectedIndex = -1;
            cbo_second_feature_rank.SelectedIndex = -1;
            cbo_bp_flanking.SelectedIndex = -1;
            rdo_centre.Checked = false;
            rdo_left.Checked = false;
            rdo_right.Checked = false;
            disable_chart1();
            //grp_analysis.Enabled = false;
            //rdo_stored.Checked = false;
            //rdo_start.Checked = false;

        }

        public void disable_chart1()
        {
            chart1.Series["Property2"].IsVisibleInLegend = false;
            chart1.Series["Property2"].LegendText = "";
            chart1.Series["Property1"].IsVisibleInLegend = false;
            chart1.Series["Property1"].LegendText = "";
            chart1.Series["Property3"].IsVisibleInLegend = false;
            chart1.Series["Property3"].LegendText = "";
            chart1.Series["SD1"].IsVisibleInLegend = false;
            chart1.Series["SD1"].LegendText = "";
            chart1.Series["SD2"].IsVisibleInLegend = false;
            chart1.Series["SD2"].LegendText = "";
            this.chart1.Series["Property1"].Points.Clear();
            this.chart1.Series["Property2"].Points.Clear();
            this.chart1.Series["Property3"].Points.Clear();
            this.chart1.Series["SD1"].Points.Clear();
            this.chart1.Series["SD2"].Points.Clear();
            cd_SD.Hide();

        }


        public void enable_chart1()
        {
            chart1.Series["Property2"].IsVisibleInLegend = true;
            chart1.Series["Property2"].LegendText = "";
            chart1.Series["Property1"].IsVisibleInLegend = true;
            chart1.Series["Property1"].LegendText = "";
            //chart1.Series["SD1"].IsVisibleInLegend = true;
            //chart1.Series["SD1"].LegendText = "";
            //chart1.Series["SD2"].IsVisibleInLegend = true;
            //chart1.Series["SD2"].LegendText = "";
            this.chart1.Series["Property1"].Points.Clear();
            this.chart1.Series["Property2"].Points.Clear();
            this.chart1.Series["SD1"].Points.Clear();
            this.chart1.Series["SD2"].Points.Clear();

        }

        public void one_species_enable_chart1_genome_level()
        {
            disable_chart1();
            //chart1.Series["Property2"].IsVisibleInLegend = true;
            // chart1.Series["Property2"].LegendText = "";
            // 
            chart1.Series["Property1"].LegendText = "";
            //chart1.Series["Property2"].LegendText = "";
            chart1.Series["Property2"].LegendText = "";
            chart1.Series["Property3"].LegendText = "";
            this.chart1.Series["Property1"].Points.Clear();
            this.chart1.Series["Property2"].Points.Clear();
            this.chart1.Series["Property3"].Points.Clear();

        }

        public void two_species_enable_chart1_genome_level()
        {
            disable_chart1();
            //chart1.Series["Property2"].IsVisibleInLegend = true;
            // chart1.Series["Property2"].LegendText = "";
            // 
            chart1.Series["Property1"].LegendText = "";
            this.chart1.Series["Property1"].Points.Clear();
            //this.chart1.Series["Property2"].Points.Clear();
            chart1.Series["Property2"].IsVisibleInLegend = false;
            chart1.Series["Property2"].LegendText = "";
            chart1.Series["Property2"].Points.Clear();
            chart1.Series["Property3"].IsVisibleInLegend = false;
            chart1.Series["Property3"].LegendText = "";
            chart1.Series["Property3"].Points.Clear();
        }

        public void frq_distribution(string species/*, string db,*/, string property, string scope, int pin/*,  double genome_length*/) 
        {
            double genome_length=0.0;
            string db="";
            if (species == "A. thaliana")
            {
                db = "HEMA_arabidopsis_thaliana_core_40_93_11";
                genome_length = 119146348.0;
            }
            else if (species == "B. rapa")
            {
                db = "HEMA_brassica_rapa_core_40_93_1";
                genome_length = 256240462.0;
            }

            else if (species == "B. oleracea")
            {
                db = "HEMA_brassica_oleracea_core_40_93_1";
                genome_length = 446885882.0;
            }

            if (species == "B. rapa" || species == "B. oleracea")
                query_p1 = "select af.values from " + db + ".attrib_frequencies af , " + db + ".attrib_type at where at.name = '" + cbo_pro_name.Text + "' " +
                " and af.attrib_type_id = at.attrib_type_id and af.scope='" + scope + "' and af.window= " + cbo_pro_win.Text + "  ";

            else
                 query_p1 = "select af.values from " + db + ".attrib_frequencies af , " + db + ".attrib_analysis at where  af.attrib_analysis_id = at.attrib_analysis_id and af.scope='" + scope + "' and at.window= " + cbo_pro_win.Text + "  ";
                        //MessageBox.Show(query_p1);
                 tb_pro1_values = runQuery(query_p1);

            //query_p1 = "select af.values from " + db + ".attrib_frequencies af , " + db + ".attrib_type at where at.name = '" + cbo_pro_name.Text + "' " +
            //" and af.attrib_type_id = at.attrib_type_id and af.scope='" + scope + "' and af.window= " + cbo_pro_win.Text + "  ";



            DataRow row = tb_pro1_values.Rows[0];
            string frq_string = "";
            frq_string = row["values"].ToString();
            List<int> frq_int = frq_string.Split(',').Select(int.Parse).ToList();

            //if (scope == "Whole genome")
            //{
            //    genome_length = frq_int.Sum();
            //}
            
            //MessageBox.Show(genome_length.ToString());
            double genome_percentage;
            int c = 0;
            for (int i = 0; i < frq_int.Count - 1; i++)
            {
                genome_percentage = (frq_int[i] * 100) / genome_length;
                //MessageBox.Show(frq_int[i].ToString());
                //MessageBox.Show((c).ToString(),genome_percentage.ToString());
                //MessageBox.Show((c).ToString());
                //MessageBox.Show(property);
                chart1.Series[property].Points.AddXY(c, genome_percentage);
                //chart1.Series["Property1"].Points.AddXY(i, frq_int[i]);
                 c = pin + c;
                //MessageBox.Show(i.ToString());
                


            }
            chart1.Series[property].LegendText = "Frequency distribution of " + cbo_pro_name.Text +" of the "+ scope +" in "+ species;
            chart1.ChartAreas[0].AxisX.Title = "%" + cbo_pro_name.Text;
            chart1.ChartAreas[0].AxisY.Title = "Percentage of genome";
            chart1.Series[property].IsVisibleInLegend = true;
        }

        public HEMA_home()
        {
            InitializeComponent();
            //Load += new EventHandler(Main_Load);

        }


        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }


        private void HEMA_home_Load(object sender, EventArgs e)
        {
            N1.Enabled = false;
            N2.Enabled = false;
            N1.Visible = false;
            N2.Visible = false;
            N_of_feature1.Enabled = false;
            N_of_feature2.Enabled = false;
            rdo_one_species.Checked = true;
            cbo_second_species.Enabled = false;
            //cmb_first_species.SelectedIndex = 0;
            cbo_pro_type.SelectedIndex = 0;
            cbo_pro_name.SelectedIndex = 0;
            //pro_win.SelectedIndex = 2;
            rdo_genic_features.Checked = true;
            rdo_whole_genome.Checked = false;
            rdo_one_feature.Checked = true;
            rdo_two_feature.Checked = false;
            cbo_second_feature.Enabled = false;
            cbo_second_feature_rank.Enabled = false;
            cbo_first_feature_rank.Enabled = false;
            cbo_second_feature_rank.Enabled = false;
            grp_analysis.Enabled = false;
            cd_SD.Hide();
            disable_chart1();
            //chart1.Legends.Clear();







        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void rbt_two_feature_CheckedChanged(object sender, EventArgs e)
        {
            Unselect_feature();
            //cbo_second_feature.Enabled = true;
            //sec_cbx_rank.Enabled = true;

        }

        private void rbt_one_feature_CheckedChanged(object sender, EventArgs e)
        {
            Unselect_feature();
            cbo_second_feature.Enabled = false;
            cbo_second_feature_rank.Enabled = false;

            grp_context.Enabled = false;
            grp_analysis.Enabled = false;

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.chart1.Series["SD2"].Points.Clear();
            this.chart1.Series["SD1"].Points.Clear();
            this.chart1.Series["Property1"].Points.Clear();
            this.chart1.Series["Property2"].Points.Clear();
            this.chart1.Series["Property3"].Points.Clear();


            cd_SD.Checked = false;
            chart1.ChartAreas[0].AxisX.Maximum = 100;
            chart1.ChartAreas[0].AxisX.Minimum = 0;

            chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;

            if (rdo_genic_features.Checked && rdo_frq_distribution.Checked)
            {
                two_species_enable_chart1_genome_level();
                frq_distribution(cbo_first_species.Text, "Property1", "Genic regions",2);
                frq_distribution(cbo_first_species.Text, "Property2", "Exonic regions",2);
                frq_distribution(cbo_first_species.Text, "Property3", "Intronic regions",2);

            }

            if (rdo_two_species.Checked && rdo_whole_genome.Checked && rdo_frq_distribution.Checked)
            {
                cd_SD.Hide();
                two_species_enable_chart1_genome_level();
                frq_distribution(cbo_first_species.Text, "Property1", "Whole genome",1);
                frq_distribution(cbo_second_species.Text, "Property2", "Whole genome",1);
                //if (cbo_first_species.SelectedIndex == 0)
                //{
                //    //MessageBox.Show("HEMA_arabidopsis_thaliana_core_40_93_11");
                //    frq_distribution(cbo_first_species.Text/*,"HEMA_arabidopsis_thaliana_core_40_93_11"*/, "Property1"/*, 118958115.0*/);

                //}
                //else if (cbo_first_species.SelectedIndex == 1)
                //{
                //    //MessageBox.Show("HEMA_brassica_rapa_core_40_93_1");
                //    frq_distribution(cbo_first_species.Text/*,"HEMA_brassica_rapa_core_40_93_1"*/, "Property1"/*, 247504619.0*/);
                //}
                //else if (cbo_first_species.SelectedIndex == 2)
                //{
                //    //MessageBox.Show("HEMA_brassica_rapa_core_40_93_1");
                //    frq_distribution(cbo_first_species.Text/*,"HEMA_brassica_rapa_core_40_93_1"*/, "Property1"/*, 247504619.0*/);
                //}

                //if (cbo_second_species.SelectedIndex == 0)
                //{
                //    //MessageBox.Show("HEMA_arabidopsis_thaliana_core_40_93_11");
                //    frq_distribution(cbo_second_species.Text,/*"HEMA_arabidopsis_thaliana_core_40_93_11",*/ "Property2"/*, 118958115.0*/);

                //}
                //else if (cbo_second_species.SelectedIndex == 1)
                //{
                //    //MessageBox.Show("HEMA_brassica_rapa_core_40_93_1");
                //    frq_distribution(cbo_second_species.Text,/*"HEMA_brassica_rapa_core_40_93_1",*/ "Property2"/*, 247504619.0*/);
                //}
                //else if (cbo_second_species.SelectedIndex == 2)
                //{
                //    //MessageBox.Show("HEMA_brassica_rapa_core_40_93_1");
                //    frq_distribution(cbo_second_species.Text,/*"HEMA_brassica_rapa_core_40_93_1",*/ "Property2"/*, 247504619.0*/);
                //}


            }


            if (rdo_one_species.Checked && rdo_whole_genome.Checked && rdo_frq_distribution.Checked) 
            {
                cd_SD.Hide();
                one_species_enable_chart1_genome_level();
                frq_distribution(cbo_first_species.Text, "Property1", "Whole genome",1);
                ////MessageBox.Show(cmb_first_species.SelectedItem.ToString());
                //if (cbo_first_species.SelectedIndex == 0) 
                //{
                //    //MessageBox.Show("HEMA_arabidopsis_thaliana_core_40_93_11");
                //    frq_distribution(cbo_first_species.Text,/* "HEMA_arabidopsis_thaliana_core_40_93_11",*/ "Property1"/*, 118958115.0*/);

                //} else if (cbo_first_species.SelectedIndex == 1)
                //{
                //    //MessageBox.Show("HEMA_brassica_rapa_core_40_93_1");
                //    frq_distribution(cbo_first_species.Text,/* "HEMA_brassica_rapa_core_40_93_1",*/ "Property1"/*, 247504619.0*/);

                //}

            }
      

            if (rdo_one_species.Checked && rdo_genic_features.Checked && rdo_pro_profile.Checked && rdo_stored.Checked )
            {
                
                //MessageBox.Show("run button1");
                //chart1.ChartAreas[0].AxisY.Maximum = 100;
                //chart1.ChartAreas[0].AxisY.Minimum = 0;
                //chart1.Enabled = true;
                disable_chart1();
                enable_chart1();
                // keep set x-axis from -500 to 500
                int bp = int.Parse(cbo_bp_flanking.Text);
                chart1.ChartAreas[0].AxisX.Maximum = +(bp);
                chart1.ChartAreas[0].AxisX.Minimum = -(bp);

                //  set y-axis in the middle of chart at zero position
                chart1.ChartAreas[0].AxisY.Crossing = 0;
                chart1.ChartAreas[0].AxisX.Crossing = 0;

                //No grid in the chart
                chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;

                //set width to the line
                //chart1.Series[0].BorderWidth = 1;
                //chart1.Series["Property1"].BorderWidth = 1;
                //chart1.Series["Property2"].BorderWidth = 1;

                //smooth chart line
                //chart1.Series[0].ChartType = SeriesChartType.Spline;
                //chart1.Series["Property1"].ChartType = SeriesChartType.Spline;
                //chart1.Series["Property2"].ChartType = SeriesChartType.Spline;


                //run query to get data GC-content values "stored_profiles"
                tb_pro1_values = runQuery(query_p1);
                

                //int count = tb_pro1_values.Select("").Length;
                //MessageBox.Show(count.ToString());
                int c = -(bp);
                int r = 0;
                foreach (DataRow row in tb_pro1_values.Rows)
                {
                    //if(r>999)
                    //    MessageBox.Show(r.ToString(), row[0].ToString());
                    chart1.Series["Property1"].Points.AddXY(c, Convert.ToDouble(row[0]));
                    meanValuesPro1[r] = Convert.ToDouble(row[0]);
                    r++;
                    c++;
                    //MessageBox.Show(row[0].ToString());
                    //chart1.Series["Property1"].Points.Add(Convert.ToInt32(row[0]));

                }



                //chart1.Series[0]["LineTension"] = "0.0";

                //show value when moving mouse over chart1
                this.chart1.MouseMove += new MouseEventHandler(chart1_MouseMove);

                // change name of peroperty and property2
                if (rdo_one_feature.Checked)
                {
                    //MessageBox.Show("Hello");
                    chart1.Series["Property1"].LegendText = cbo_first_feature.Text + "#" + cbo_first_feature_rank.Text;
                    chart1.Series["Property2"].IsVisibleInLegend = false;
                    //chart1.Series["Property2"].LegendText = "";
                    


                }

                if (rdo_two_feature.Checked)
                {
                    tb_pro2_values = runQuery(query_p2);
                    c = -(bp);
                    r = 0;
                    foreach (DataRow row in tb_pro2_values.Rows)
                    {
                        chart1.Series["Property2"].Points.AddXY(c, Convert.ToDouble(row[0]));
                        meanValuesPro2[r] = Convert.ToDouble(row[0]);
                        c++;
                        r++;
                        //        //MessageBox.Show(row[0].ToString());


                    }
                    chart1.Series["Property1"].LegendText = cbo_first_feature.Text + " " + cbo_first_feature_rank.Text;
                    chart1.Series["Property2"].LegendText = cbo_second_feature.Text + " " + cbo_second_feature_rank.Text;

                }
                //else
                //{
                //    tb_pro2_values = runQuery(query_p2);
                //    c = -(bp);
                //    r = 0;
                //    foreach (DataRow row in tb_pro2_values.Rows)
                //    {
                //        chart1.Series["Property2"].Points.AddXY(c, Convert.ToDouble(row[0]));
                //        meanValuesPro2[r] = Convert.ToDouble(row[0]);
                //        c++;
                //        r++;
                //        //MessageBox.Show(row[0].ToString());
                //        //chart1.Series["Property2"].Points.Add(Convert.ToInt32(row[0]));

                //    }
                //    chart1.Series["Property1"].LegendText = cbo_first_feature.Text + " " + cbo_first_feature_rank.Text;
                //    chart1.Series["Property2"].LegendText = cbo_second_feature.Text + " " + cbo_second_feature_rank.Text;

                //}

                // add name to x and y-axis

            


                chart1.ChartAreas[0].AxisX.Title = "bp";
                chart1.ChartAreas[0].AxisY.Title = cbo_pro_name.Text;
                cd_SD.Visible = true;
                //this.chart1.Update();
                //save.Enabled = true;

                






            }

            if (rdo_one_species.Checked && rdo_genic_features.Checked && rdo_pro_profile.Checked && rdo_start.Checked)
            {
                //MessageBox.Show("Hello_run");
                //int bp = int.Parse(cbo_bp_flanking.Text);
                //MessageBox.Show("Hello");
                h = 0;
                //MessageBox.Show(numberOfFeature1.ToString());
                GCarray = new Double[numberOfFeature1, (Convert.ToInt32(cbo_bp_flanking.Text) * 2) + 1];
                gcAVGarray = new Double[(Convert.ToInt32(cbo_bp_flanking.Text) * 2) + 1]; 
                gcSDarray= new Double[(Convert.ToInt32(cbo_bp_flanking.Text) * 2) + 1];
                SDarray = new Double[numberOfFeature1];



                //GCarray = new Double[numberOfFeature1, (Convert.ToInt32(cbo_bp_flanking.Text)*2)+1];
                //gcAVGarray = new Double[(Convert.ToInt32(cbo_bp_flanking.Text)*2)+1];


                if (rdo_one_feature.Checked)
                {
                    
                    int bp = int.Parse(cbo_bp_flanking.Text);
                    chart1.ChartAreas[0].AxisX.Maximum = +(bp);
                    chart1.ChartAreas[0].AxisX.Minimum = -(bp);

                    chart1.ChartAreas[0].AxisY.Crossing = 0;
                    chart1.ChartAreas[0].AxisX.Crossing = 0;

                    //No grid in the chart
                    chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                    chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;

                    //chart1.ChartAreas["ChartArea1"].AxisY.Maximum = 60;

                    if (rdo_centre.Checked)
                    {
                        foreach (DataRow row in allfeature1.Rows)
                        {
                            //MessageBox.Show("Hello");
                            //strand = row["Strand"].ToString();
                            strand = Convert.ToInt32(row["Strand"]);
                            centre = int.Parse(cbo_bp_flanking.Text);
                            center = ((int)(row["Start"]) + (int)(row["End"])) / 2;
                            start = (center - centre).ToString();
                            end = (center + centre).ToString();
                            seq_region_id = (row["seq_region_id"]).ToString();
                            //MessageBox.Show(center.ToString());
                            //MessageBox.Show(start.ToString());
                            //MessageBox.Show(end.ToString());
                            centre_right_left(start, end, seq_region_id, bp, strand);
                        }
                    }

                    if (rdo_right.Checked)
                    {
                        foreach (DataRow row in allfeature1.Rows)
                        {
                            right = int.Parse(cbo_bp_flanking.Text);
                            strand = Convert.ToInt32(row["Strand"]);
                            //strand = row["Strand"].ToString();
                            if (Convert.ToInt32(strand) == 1)
                            {
                                start = ((int)(row["End"]) - (right)).ToString();
                                end = ((int)(row["End"]) + (right)).ToString();
                            }
                            else
                            {
                                start = ((int)(row["Start"]) - (right)).ToString();
                                end = ((int)(row["Start"]) + (right)).ToString();

                            }
                            seq_region_id = (row["seq_region_id"]).ToString();
                            centre_right_left(start, end, seq_region_id, bp, strand);

                        }
                    }

                    if (rdo_left.Checked)
                    {

                        foreach (DataRow row in allfeature1.Rows)
                        {
                            left = int.Parse(cbo_bp_flanking.Text);
                            strand = Convert.ToInt32(row["Strand"]);
                            //strand = row["Strand"].ToString();
                            if (Convert.ToInt32(strand) == 1)
                            {
                                start = ((int)(row["Start"]) - (left)).ToString();
                                end = ((int)(row["Start"]) + (left)).ToString();

                            }
                            else
                            {
                                start = ((int)(row["End"]) - (left)).ToString();
                                end = ((int)(row["End"]) + (left)).ToString();
                            }
                            seq_region_id = (row["seq_region_id"]).ToString();
                            centre_right_left(start, end, seq_region_id, bp, strand);

                        }
                    }

                    //for (int row = 0; row < GCarray.GetLength(0); row++)
                    //{
                    //    MessageBox.Show(GCarray[0,row].ToString());

                    //}
                    MessageBox.Show("before avg");
                    gcAVGarray = rowWiseAvg(GCarray);
                    //calculateStandardDeviation(GCarray);
                    SDarray=calculateStandardDeviation(GCarray);

                    //int rows = gcAVGarray.GetLength(1);
                    //for (int row = 0; row < cols; row++)
                    //{
                    //    Console.Write(gcAVGarray[][ column] + " ");
                    //}




                    //for (int row = 0; row < gcAVGarray.GetLength(0); row++)
                    //{
                    //    MessageBox.Show(gcAVGarray[row].ToString());

                    //}
                    //MessageBox.Show(gcAVGarray.Length.ToString());
                    int c = -(bp);
                    for (int row = 0; row < gcAVGarray.GetLength(0); row++)
                    {
                        //MessageBox.Show((gcAVGarray[row]).ToString());
                        //chart1.Series["Property2"].Points.AddXY(c,gcAVGarray[row]);

                        chart1.Series["Property2"].Points.AddXY(c, Convert.ToDouble(gcAVGarray[row]));
                        c++;
                    }




                }

                chart1.ChartAreas[0].AxisX.Title = "bp";
                chart1.ChartAreas[0].AxisY.Title = cbo_pro_name.Text;

            }



                this.chart1.MouseMove += new MouseEventHandler(chart1_MouseMove);
            this.chart1.Update();
            btn_save.Enabled = true;
            
        }

        private void rb_ana_lev1_CheckedChanged(object sender, EventArgs e)
        {
            rdo_pro_profile.Enabled = false;
            grp_features.Enabled = false;
            grp_context.Enabled = false;
            Unselect_feature();

            grp_analysis.Enabled = true;
            rdo_frq_distribution.Checked = true;

            //adding property_window (101,201,301,401,501) range for genome level
            BindingSource bs = new BindingSource();
            bs.DataSource = new List<string> { "101", "201","301","401","501" };
            cbo_pro_win.DataSource = bs;
            cbo_pro_win.SelectedIndex = 4;



        }

        private void sec_cbx_rank_SelectedIndexChanged(object sender, EventArgs e)
        {
            grp_context.Enabled = true;
            cbo_bp_flanking.Enabled = false;
            cbo_bp_flanking.SelectedIndex = -1;
            rdo_centre.Checked = false;
            rdo_left.Checked = false;
            rdo_right.Checked = false;
            cbo_bp_flanking.Enabled = false;
            //cbo_bp_flanking.Text = "";
            disable_chart1();

            if (rdo_two_feature.Checked)
            {
                grp_context.Enabled = true;
                cbo_bp_flanking.Enabled = false;
            }

        }

        private void fir_cbx_rank_Click(object sender, EventArgs e)
        {
            //query genome feature ranking
            // filling > fir_cbx_rank
            query_rank1 = "SELECT DISTINCT srp.rank FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature srp WHERE feature_id ='" + feature_id1 + "' ; ";
            tb_rank1 = runQuery(query_rank1);
            tb_rank1.Columns[0].ColumnName = "Rank";
            cbo_first_feature_rank.DataSource = tb_rank1;
            cbo_first_feature_rank.DisplayMember = "Rank";
            cbo_first_feature_rank.ValueMember = "Rank";



        }

        private void cmb_feature1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbo_first_feature.Text)
            {
                case "Exon":
                    feature_id1 = "EX";
                    break;
                case "Intron":
                    feature_id1 = "IN";
                    break;
                case "5'UTR Exon":
                    feature_id1 = "E5";
                    break;
                case "5'UTR Intron":
                    feature_id1 = "I5";
                    break;
                case "3'UTR Exon":
                    feature_id1 = "E3";
                    break;
                case "3'UTR Intron":
                    feature_id1 = "I3";
                    break;
            }
            cbo_first_feature_rank.Enabled = true;
            cbo_first_feature_rank.SelectedIndex = -1;
            rdo_right.Checked = false;
            rdo_left.Checked = false;
            rdo_centre.Checked = false;
            cbo_bp_flanking.SelectedIndex = -1;
            grp_context.Enabled = false;
        }

        private void cmb_feature2_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbo_second_feature.Text)
            {
                case "Exon":
                    feature_id2 = "EX";
                    break;
                case "Intron":
                    feature_id2 = "IN";
                    break;
                case "5'UTR Exon":
                    feature_id2 = "E5";
                    break;
                case "5'UTR Intron":
                    feature_id2 = "I5";
                    break;
                case "3'UTR Exon":
                    feature_id2 = "E3";
                    break;
                case "3'UTR Intron":
                    feature_id2 = "I3";
                    break;
            }
            cbo_second_feature_rank.Enabled = true;
            cbo_second_feature_rank.SelectedIndex = -1;
            rdo_right.Checked = false;
            rdo_left.Checked = false;
            rdo_centre.Checked = false;
            cbo_bp_flanking.SelectedIndex = -1;
            grp_context.Enabled = false;
        }

        private void rb1_CheckedChanged(object sender, EventArgs e)
        {
            cbo_bp_flanking.Enabled = true;
            context = "Left";
            cbo_bp_flanking.SelectedIndex = -1;
            grp_analysis.Enabled = false;
            rdo_stored.Checked = false;
            rdo_start.Checked = false;
        }

        private void cbo_first_feature_rank_SelectionChangeCommitted(object sender, EventArgs e)
        {

            N1.Visible = true;
            N1.Enabled = true;
            N_of_feature1.Enabled = true;
            //MessageBox.Show(cbo_first_feature_rank.SelectedValue.ToString());
            string query_countfeature1;
            query_countfeature1 = "SELECT count(*) FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature tf, HEMA_arabidopsis_thaliana_core_40_93_11.transcript t " +
            "WHERE tf.transcript_id = t.transcript_id AND tf.feature_id = '" + feature_id1 + "' AND tf.rank = " + cbo_first_feature_rank.SelectedValue.ToString() + " AND t.biotype = 'protein_coding' ";
            int n = runQueryScalarValue(query_countfeature1);
            N_of_feature1.Text = (n).ToString();
            N_of_feature1.Text = (23108).ToString();

        }

        private void cbo_second_feature_rank_SelectionChangeCommitted(object sender, EventArgs e)
        {
            N2.Visible = true;
            N2.Enabled = true;
            N_of_feature2.Enabled = true;
            //MessageBox.Show(cbo_first_feature_rank.SelectedValue.ToString());
            string query_countfeature1;
            query_countfeature1 = "SELECT count(*) FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature tf, HEMA_arabidopsis_thaliana_core_40_93_11.transcript t " +
            "WHERE tf.transcript_id = t.transcript_id AND tf.feature_id = '" + feature_id2 + "' AND tf.rank = " + cbo_second_feature_rank.SelectedValue.ToString() + " AND t.biotype = 'protein_coding' ";
            int n = runQueryScalarValue(query_countfeature1);
            N_of_feature2.Text = (n).ToString();
            N_of_feature2.Text = (17406).ToString();
        }

        private void rb3_CheckedChanged(object sender, EventArgs e)
        {
            cbo_bp_flanking.Enabled = true;
            context = "Right";
            cbo_bp_flanking.SelectedIndex = -1;
            grp_analysis.Enabled = false;
            rdo_stored.Checked = false;
            rdo_start.Checked = false;
        }

        private void rb2_CheckedChanged(object sender, EventArgs e)
        {
            cbo_bp_flanking.Enabled = true;
            context = "Centre";
            cbo_bp_flanking.SelectedIndex = -1;
            grp_analysis.Enabled = false;
            rdo_stored.Checked = false;
            rdo_start.Checked = false;
        }

       private void button2_Click(object sender, EventArgs e)
        {
            this.chart1.SaveImage("C:\\Users\\aibrah13\\Pictures\\mychart.png", ChartImageFormat.Png);
        }



        private void two_species_CheckedChanged(object sender, EventArgs e)
        {
            
            //cmb_second_species.Items.Clear();
            //cmb_first_species.Items.Clear();
            cbo_second_species.Enabled = true;
            //cmb_first_species.Items.AddRange(new string[] { "A. thaliana", "B. rapa" });
            //cmb_second_species.Items.AddRange(new string[] { "A. thaliana", "B. rapa" });
            cbo_first_species.SelectedIndex = 0;
            cbo_second_species.SelectedIndex = 1;
            rdo_whole_genome.Checked = true;
            rdo_frq_distribution.Checked = true;
            rdo_genic_features.Enabled = false;
            rdo_pro_profile.Enabled = false;
            grp_analysis.Enabled = true;

            //if (cmb_first_species.Text=="A. thaliana") 
            //{
            //    cmb_second_species.Items.Remove("A. thaliana");
            //}
            //if (cmb_first_species.Text == "B. rapa")
            //{
            //    cmb_second_species.Items.Remove("B. rapa");
            //}
        }

        private void cmb_first_species_SelectedValueChanged(object sender, EventArgs e)
        {
            //if (cbo_first_species.Text == cbo_second_species.Text)
            //{
            //    cbo_first_species.SelectedIndex = 0;
            //    cbo_second_species.SelectedIndex = 1;
            //}

            //if (cbo_first_species.SelectedIndex==0 && rdo_two_species.Checked)
            //{
            //    cbo_second_species.SelectedIndex = 1;
            //    //cmb_second_species.Items.Clear();
            //    //cmb_second_species.Items.Add("B. rapa");
            //}
            //if (cbo_first_species.Text == "B. rapa" && rdo_two_species.Checked)
            //{
            //    cbo_second_species.SelectedIndex = 2;
            //    //cmb_second_species.Items.Clear();
            //    //cmb_second_species.Items.Add("A. thaliana");
            //}
            //if (cbo_first_species.Text == "B. oleracea" && rdo_two_species.Checked)
            //{
            //    cbo_second_species.SelectedIndex = 0;
            //    //cmb_second_species.Items.Clear();
            //    //cmb_second_species.Items.Add("A. thaliana");
            //}

        }

        private void one_species_CheckedChanged(object sender, EventArgs e)
        {
            
            //cmb_first_species.Items.Clear();
            //cmb_first_species.Items.AddRange(new string[] { "A. thaliana", "B. rapa" });
            cbo_first_species.SelectedIndex = 0;
            cbo_second_species.SelectedIndex = -1;
            cbo_second_species.Enabled = false;
            //cmb_second_species.Items.Clear();
            rdo_genic_features.Enabled = true;
            rdo_genic_features.Checked = true;
            rdo_pro_profile.Enabled=true;
            rdo_pro_profile.Checked = true;
            cbo_pro_win.SelectedIndex = 2;
        }


        private void cmb_second_species_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbo_first_species.Text == cbo_second_species.Text)
            {
                cbo_first_species.SelectedIndex = 0;
                cbo_second_species.SelectedIndex = 1;
            }
            //if (cbo_second_species.Text == "B. rapa" && rdo_two_species.Checked)
            //{
            //    cbo_first_species.SelectedIndex = 0;
            //    //cmb_second_species.Items.Clear();
            //    //cmb_second_species.Items.Add("B. rapa");
            //}
            //if (cbo_second_species.Text == "A. thaliana" && rdo_two_species.Checked)
            //{
            //    cbo_first_species.SelectedIndex = 2;
            //    //cmb_second_species.Items.Clear();
            //    //cmb_second_species.Items.Add("A. thaliana");
            //}
            //if (cbo_second_species.Text == "B. oleracea" && rdo_two_species.Checked)
            //{
            //    cbo_first_species.SelectedIndex = 1;
            //    //cmb_second_species.Items.Clear();
            //    //cmb_second_species.Items.Add("B. rapa");
            //}
        }

        private void rb_frq_distribution_CheckedChanged(object sender, EventArgs e)
        {
            grp_analysis.Enabled = true;
            rdo_stored.Checked = true;
            rdo_start.Enabled = false;
            btn_save.Enabled = false;
            grp_features.Enabled = false;
            grp_context.Enabled = false;

            if (rdo_genic_features.Checked && rdo_frq_distribution.Checked)
            {
                BindingSource bs = new BindingSource();
                bs.DataSource = new List<string> { "51" ,"101"};
                cbo_pro_win.DataSource = bs;
            }

            cbo_first_feature.SelectedIndex = -1;
            cbo_first_feature_rank.SelectedIndex = -1;
            cbo_second_feature.SelectedIndex = -1;
            cbo_second_feature_rank.SelectedIndex = -1;
            rdo_right.Checked = false;
            rdo_left.Checked = false;
            rdo_centre.Checked = false;
            cbo_bp_flanking.SelectedIndex = -1;




        }

        private void rb_pro_profile_CheckedChanged(object sender, EventArgs e)
        {
            grp_analysis.Enabled = false;
            grp_features.Enabled = true;
            cbo_first_feature.SelectedIndex = -1;
            cbo_first_feature_rank.SelectedIndex = -1;
            cbo_second_feature.SelectedIndex = -1;
            cbo_second_feature_rank.SelectedIndex = -1;

            BindingSource bs = new BindingSource();
            bs.DataSource = new List<string> { "11", "33", "101" };
            cbo_pro_win.DataSource = bs;
            cbo_pro_win.SelectedIndex = 2;




        }

        private void rbt_start_CheckedChanged(object sender, EventArgs e)
        {
            //h = 0;
            ////MessageBox.Show(numberOfFeature1.ToString());
            //GCarray = new Double[numberOfFeature1, (Convert.ToInt32(cbo_bp_flanking.Text) * 2) + 1];
            //gcAVGarray = new Double[(Convert.ToInt32(cbo_bp_flanking.Text) * 2) + 1];
            ////GCarray = new Double[numberOfFeature1, (Convert.ToInt32(cbo_bp_flanking.Text)*2)+1];
            ////gcAVGarray = new Double[(Convert.ToInt32(cbo_bp_flanking.Text)*2)+1];

            //if (rdo_one_feature.Checked)
            //{
            //    int bp = int.Parse(cbo_bp_flanking.Text);
            //    chart1.ChartAreas[0].AxisX.Maximum = +(bp);
            //    chart1.ChartAreas[0].AxisX.Minimum = -(bp);

            //    chart1.ChartAreas[0].AxisY.Crossing = 0;
            //    chart1.ChartAreas[0].AxisX.Crossing = 0;

            //    //No grid in the chart
            //    chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            //    chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;

            //    //chart1.ChartAreas["ChartArea1"].AxisY.Maximum = 60;

            //    if (rdo_centre.Checked)
            //    {
            //        foreach (DataRow row in allfeature1.Rows) 
            //        {
            //            //strand = row["Strand"].ToString();
            //            strand = Convert.ToInt32(row["Strand"]);
            //            centre = int.Parse(cbo_bp_flanking.Text);
            //            center = ((int)(row["Start"]) + (int)(row["End"])) / 2;
            //            start = (center - centre).ToString();
            //            end = (center + centre).ToString();
            //            seq_region_id = (row["seq_region_id"]).ToString();
            //            //MessageBox.Show(center.ToString());
            //            //MessageBox.Show(start.ToString());
            //            //MessageBox.Show(end.ToString());
            //            centre_right_left(start, end, seq_region_id,bp,strand);
            //        }
            //    }

            //    if (rdo_right.Checked)
            //    {
            //        foreach (DataRow row in allfeature1.Rows)
            //        {
            //            right = int.Parse(cbo_bp_flanking.Text);
            //            strand = Convert.ToInt32(row["Strand"]);
            //            //strand = row["Strand"].ToString();
            //            if (Convert.ToInt32(strand) == 1)
            //            {
            //                start = ((int)(row["End"]) - (right)).ToString();
            //                end = ((int)(row["End"]) + (right)).ToString();
            //            }
            //            else {
            //                start = ((int)(row["Start"]) - (right)).ToString();
            //                end = ((int)(row["Start"]) + (right)).ToString();

            //            }  
            //            seq_region_id = (row["seq_region_id"]).ToString();
            //            centre_right_left(start, end, seq_region_id, bp,strand);

            //        }
            //    }

            //    if (rdo_left.Checked)
            //    {

            //        foreach (DataRow row in allfeature1.Rows)
            //        {
            //            left = int.Parse(cbo_bp_flanking.Text);
            //            strand = Convert.ToInt32(row["Strand"]);
            //            //strand = row["Strand"].ToString();
            //            if (Convert.ToInt32(strand) == 1)
            //            {
            //                start = ((int)(row["Start"]) - (left)).ToString();
            //                end = ((int)(row["Start"]) + (left)).ToString();

            //            }
            //            else {
            //                start = ((int)(row["End"]) - (left)).ToString();
            //                end = ((int)(row["End"]) + (left)).ToString();
            //            }
            //            seq_region_id = (row["seq_region_id"]).ToString();
            //            centre_right_left(start, end, seq_region_id, bp,strand);

            //        }
            //    }

            //    //for (int row = 0; row < GCarray.GetLength(0); row++)
            //    //{
            //    //    MessageBox.Show(GCarray[0,row].ToString());
                    
            //    //}

            //    gcAVGarray = rowWiseAvg(GCarray);


            //    //for (int row = 0; row < gcAVGarray.GetLength(0); row++)
            //    //{
            //    //    MessageBox.Show(gcAVGarray[row].ToString());

            //    //}
            //    //MessageBox.Show(gcAVGarray.Length.ToString());
            //    int c = -(bp);
            //    for (int row = 0; row < gcAVGarray.GetLength(0); row++)
            //    {
            //        //MessageBox.Show((gcAVGarray[row]).ToString());
            //        //chart1.Series["Property2"].Points.AddXY(c,gcAVGarray[row]);

            //        chart1.Series["Property2"].Points.AddXY(c, Convert.ToDouble(gcAVGarray[row]));
            //        c++;
            //    }




            //}



        }

        private void SD_CheckedChanged(object sender, EventArgs e)
        {
            if (cd_SD.Checked)
            {
                this.chart1.Series["SD1"].Points.Clear();
                chart1.Series["SD1"].IsVisibleInLegend = true;
                chart1.Series["SD1"].LegendText = "SD of "+cbo_first_feature.Text+"#" + cbo_first_feature_rank.Text;



                //chart1.Series.Add(new Series("+SD"));
                //chart1.Series.Add(new Series("-SD"));

                int bp = int.Parse(cbo_bp_flanking.Text);
                chart1.ChartAreas[0].AxisX.Maximum = +(bp);
                chart1.ChartAreas[0].AxisX.Minimum = -(bp);
                int c = -(bp);
                int r = 0;
                Double mean, valueUp, valueDown;

                foreach (DataRow row in tb_pro1_SD_values.Rows)
                {
                    mean = meanValuesPro1[r];
                    valueUp = mean + Convert.ToDouble(row[0]);
                    valueDown = mean - Convert.ToDouble(row[0]);
                    chart1.Series["SD1"].Points.AddXY(c, valueDown, valueUp);
                    //chart1.Series["SD"].Points.AddXY(c, valueDown);
                    c++;
                    r++;
                    //MessageBox.Show(row[0].ToString());
                    //chart1.Series["Property1"].Points.Add(Convert.ToInt32(row[0]));

                }

                if (rdo_two_feature.Checked)
                {
                    this.chart1.Series["SD2"].Points.Clear();
                    chart1.Series["SD2"].IsVisibleInLegend = true;
                    //chart1.Series["SD2"].LegendText = "";
                    chart1.Series["SD2"].LegendText = "SD of " + cbo_second_feature.Text + "#" + cbo_second_feature_rank.Text;
                    chart1.ChartAreas[0].AxisX.Maximum = +(bp);
                    chart1.ChartAreas[0].AxisX.Minimum = -(bp);
                    c = -(bp);
                    r = 0;
                    foreach (DataRow row in tb_pro2_SD_values.Rows)
                    {
                        mean = meanValuesPro2[r];
                        valueUp = mean + Convert.ToDouble(row[0]);
                        valueDown = mean - Convert.ToDouble(row[0]);
                        chart1.Series["SD2"].Points.AddXY(c, valueDown, valueUp);
                        //chart1.Series["SD"].Points.AddXY(c, valueDown);
                        c++;
                        r++;
                        //MessageBox.Show(row[0].ToString());
                        //chart1.Series["Property1"].Points.Add(Convert.ToInt32(row[0]));

                    }
                }

                //chart1.Series.Add(new Series("+SD"));
                //chart1.Series.Add(new Series("-SD"));

            }
            else {
                //MessageBox.Show("unchecked");
                this.chart1.Series["SD2"].Points.Clear();
                this.chart1.Series["SD1"].Points.Clear();
                chart1.Series["SD1"].IsVisibleInLegend = false;
                chart1.Series["SD1"].LegendText = "";
                chart1.Series["SD2"].IsVisibleInLegend = false;
                chart1.Series["SD2"].LegendText = "";

            }





        }

        private void bp_flanking_SelectedIndexChanged(object sender, EventArgs e)
        {
            rdo_start.Checked = false;
            rdo_stored.Checked = false;
            if (cbo_bp_flanking.SelectedIndex != -1)
            {
                if (rdo_one_species.Checked && rdo_genic_features.Checked && rdo_pro_profile.Checked)
                {
                    grp_analysis.Enabled = true;
                    rdo_start.Enabled = true;
                    rdo_stored.Enabled = false;
                    btn_save.Enabled = false;
                    if (rdo_one_feature.Checked)
                    {
                        int rank1value = int.Parse(cbo_first_feature_rank.SelectedValue.ToString());
                        
                        if (rank1value < 10)
                        {

                            rdo_stored.Enabled = true;
                            rdo_stored.Checked = true;

                        }
                        else
                        {
                            //MessageBox.Show(rank1value.ToString());
                            //start_still
                            //start_here

                            //get the count of selected feature#1 to create array with that number in order to prepare start button to run
                            //string query_countfeature1;
                            //query_countfeature1 = "SELECT count(*) FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature tf, HEMA_arabidopsis_thaliana_core_40_93_11.transcript t " +
                            //"WHERE tf.transcript_id = t.transcript_id AND tf.feature_id = '" + feature_id1 + "' AND tf.rank = " + cbo_first_feature_rank.Text + " AND t.biotype = 'protein_coding' ";
                            //N_of_feature1.Text = (query_countfeature1).ToString();

                            //numberOfFeature1 = runQueryScalarValue(query_countfeature1);

                            //MessageBox.Show(numberOfFeature1.ToString());

                            //get coordinates, length, strand and rank of feature_1
                            query_all_feature1 = "select tf.feature_id, tf.seq_region_pos_start, tf.seq_region_pos_end, (tf.seq_region_pos_end - tf.seq_region_pos_start)+1 as Length, tf.seq_region_strand, tf.rank, t.seq_region_id " +
                            " FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature tf, HEMA_arabidopsis_thaliana_core_40_93_11.transcript t " +
                            "WHERE tf.transcript_id = t.transcript_id AND tf.feature_id = '" + feature_id1 + "' AND tf.rank = " + cbo_first_feature_rank.Text + " AND t.biotype = 'protein_coding' ";
                            //MessageBox.Show("Hello");
                            //MessageBox.Show(query_all_feature1);
                            
                            allfeature1 = runQuery(query_all_feature1);
                            numberOfFeature1 = allfeature1.Select("").Length;

                            allfeature1.Columns[0].ColumnName = "Code";
                            allfeature1.Columns[1].ColumnName = "Start";
                            allfeature1.Columns[2].ColumnName = "End";
                            allfeature1.Columns[3].ColumnName = "Length";
                            allfeature1.Columns[4].ColumnName = "Strand";
                            allfeature1.Columns[5].ColumnName = "Rank";
                            allfeature1.Columns[6].ColumnName = "seq_region_id";
                            //foreach (DataRow row in allfeature1.Rows)
                            //{
                            //    strand = row["Strand"].ToString();
                            //    centre = int.Parse(cbo_bp_flanking.Text);
                            //    center = ((int)(row["Start"]) + (int)(row["End"])) / 2;
                            //    start = (center - centre).ToString();
                            //    end = (center + centre).ToString();
                            //    seq_region_id = (int)(row["seq_region_id"]);
                            //    //MessageBox.Show(start, end);
                            //}
                            //MessageBox.Show(numberOfFeatures.ToString());
                            //select start radio_button
                            rdo_start.Enabled = true;
                            rdo_start.Checked = true;

                        }




                    }

                    else
                    {
                        int rank1value = int.Parse(cbo_first_feature_rank.SelectedValue.ToString());
                        int rank2value = int.Parse(cbo_second_feature_rank.SelectedValue.ToString());
                        if ((rank1value < 10) && (rank2value < 10))
                        {
                            rdo_stored.Enabled = true;
                            rdo_stored.Checked = true;


                        }
                        //MessageBox.Show("here_4");
                    }


                }

            }


            //MessageBox.Show("here");


        }

        private void rbt_stored_CheckedChanged(object sender, EventArgs e)
        {

            //MessageBox.Show("hello");
            if (cbo_bp_flanking.SelectedIndex != -1)
            {
                /*query_y = "select y_axis_value from HEMA_arabidopsis_thaliana_core_40_93_11.feature_attrib_analysis_output faao,"+
    "HEMA_arabidopsis_thaliana_core_40_93_11.feature_attrib_analysis faa where faa.feature_id = '" + feature_id1 + "'"+
    "and faao.feature_attrib_analysis_id = faa.feature_attrib_analysis_id " +
    " and faao.x_axis_value between " +"-"+ bp_flanking.Text + "  and " + bp_flanking.Text + " ";*/
                if (rdo_one_species.Checked && rdo_genic_features.Checked && rdo_pro_profile.Checked && rdo_two_feature.Checked)
                {
                    query_p1 = "select faao.y_axis_value from attrib_analysis aa, attrib_type at, feature_attrib_analysis faa," +
                         "1_feature_attrib_analysis_output faao where aa.attrib_analysis_id = faa.attrib_analysis_id " +
                         "and faa.feature_attrib_analysis_id = faao.feature_attrib_analysis_id and faa.data_type = 'Mean' " +
                         "and aa.window = " + cbo_pro_win.Text + " and faa.feature_id='" + feature_id1 + "' " +
                         " and faao.x_axis_value between " + "-" + cbo_bp_flanking.Text + "  and " + cbo_bp_flanking.Text + " " +
                         "and faa.feature_counter= " + cbo_first_feature_rank.Text + " and faa.context='" + context + "' and at.name = '" + cbo_pro_name.Text + "' ORDER BY feature_attrib_analysis_output_id";
                    //MessageBox.Show(query_p1);
                    tb_pro1_values = runQuery(query_p1);

                    //SD
                    query_SD = "select faao.y_axis_value from attrib_analysis aa, attrib_type at, feature_attrib_analysis faa," +
                        "1_feature_attrib_analysis_output faao where aa.attrib_analysis_id = faa.attrib_analysis_id " +
                         "and faa.feature_attrib_analysis_id = faao.feature_attrib_analysis_id and faa.data_type='Standard deviation' " +
                         "and aa.window = " + cbo_pro_win.Text + " and faa.feature_id='" + feature_id1 + "' " +
                         " and faao.x_axis_value between " + "-" + cbo_bp_flanking.Text + "  and " + cbo_bp_flanking.Text + " " +
                         "and faa.feature_counter= " + cbo_first_feature_rank.Text + " and faa.context='" + context + "' and at.name = '" + cbo_pro_name.Text + "' ORDER BY feature_attrib_analysis_output_id";
                    //MessageBox.Show(query_SD);
                    tb_pro1_SD_values = runQuery(query_SD);



                    query_p2 = "select faao.y_axis_value from attrib_analysis aa, attrib_type at, feature_attrib_analysis faa," +
                            "1_feature_attrib_analysis_output faao where aa.attrib_analysis_id = faa.attrib_analysis_id " +
                               "and faa.feature_attrib_analysis_id = faao.feature_attrib_analysis_id and faa.data_type = 'Mean' " +
                                "and aa.window = " + cbo_pro_win.Text + " and faa.feature_id='" + feature_id2 + "' " +
                                " and faao.x_axis_value between " + "-" + cbo_bp_flanking.Text + "  and " + cbo_bp_flanking.Text + " " +
                                "and faa.feature_counter= " + cbo_second_feature_rank.Text + " and faa.context='" + context + "' and at.name = '" + cbo_pro_name.Text + "' ORDER BY feature_attrib_analysis_output_id";
                    //MessageBox.Show(query_p2);
                    tb_pro2_values = runQuery(query_p2);

                    query_SD2 = "select faao.y_axis_value from attrib_analysis aa, attrib_type at, feature_attrib_analysis faa," +
                            "1_feature_attrib_analysis_output faao where aa.attrib_analysis_id = faa.attrib_analysis_id " +
                            "and faa.feature_attrib_analysis_id = faao.feature_attrib_analysis_id and faa.data_type='Standard deviation' " +
                             "and aa.window = " + cbo_pro_win.Text + " and faa.feature_id='" + feature_id2 + "' " +
                             " and faao.x_axis_value between " + "-" + cbo_bp_flanking.Text + "  and " + cbo_bp_flanking.Text + " " +
                             "and faa.feature_counter= " + cbo_second_feature_rank.Text + " and faa.context='" + context + "' and at.name = '" + cbo_pro_name.Text + "' ORDER BY feature_attrib_analysis_output_id";
                    //MessageBox.Show(query_SD2);
                    tb_pro2_SD_values = runQuery(query_SD2);

                }

                if (rdo_one_species.Checked && rdo_genic_features.Checked && rdo_pro_profile.Checked && rdo_one_feature.Checked)
                {
                    //MessageBox.Show("if statment");
                    query_p1 = "select faao.y_axis_value from attrib_analysis aa, attrib_type at, feature_attrib_analysis faa," +
                         "1_feature_attrib_analysis_output faao where aa.attrib_analysis_id = faa.attrib_analysis_id " +
                         "and faa.feature_attrib_analysis_id = faao.feature_attrib_analysis_id and faa.data_type='Mean' " +
                         "and aa.window = " + cbo_pro_win.Text + " and faa.feature_id='" + feature_id1 + "' " +
                         " and faao.x_axis_value between " + "-" + cbo_bp_flanking.Text + "  and " + cbo_bp_flanking.Text + " " +
                         "and faa.feature_counter= " + cbo_first_feature_rank.Text + " and faa.context='" + context + "' and at.name = '" + cbo_pro_name.Text + "' ORDER BY feature_attrib_analysis_output_id";
                    //MessageBox.Show(query_p1);
                    tb_pro1_values = runQuery(query_p1);


                    //SD
                    query_SD = "select faao.y_axis_value from attrib_analysis aa, attrib_type at, feature_attrib_analysis faa," +
                        "1_feature_attrib_analysis_output faao where aa.attrib_analysis_id = faa.attrib_analysis_id " +
                         "and faa.feature_attrib_analysis_id = faao.feature_attrib_analysis_id and faa.data_type='Standard deviation' " +
                         "and aa.window = " + cbo_pro_win.Text + " and faa.feature_id='" + feature_id1 + "' " +
                         " and faao.x_axis_value between " + "-" + cbo_bp_flanking.Text + "  and " + cbo_bp_flanking.Text + " " +
                         "and faa.feature_counter= " + cbo_first_feature_rank.Text + " and faa.context='" + context + "' and at.name = '" + cbo_pro_name.Text + "' ORDER BY feature_attrib_analysis_output_id";
                    //MessageBox.Show(query_SD);
                    tb_pro1_SD_values = runQuery(query_SD);

                }

            }




        }

        private void fir_cbx_rank_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rdo_one_feature.Checked)
            {
                grp_context.Enabled = true;
                cbo_bp_flanking.Enabled = false;
                cbo_bp_flanking.SelectedIndex = -1;
                rdo_centre.Checked = false;
                rdo_left.Checked = false;
                rdo_right.Checked = false;
                cbo_bp_flanking.Enabled = false;
                //cbo_bp_flanking.Text = "";
                disable_chart1();


                //MessageBox.Show(cbo_first_feature_rank.SelectedIndex.ToString());
                //if (cbo_first_feature_rank.SelectedIndex > 0)
                //{
                //    N1.Visible = true;
                //    N1.Enabled = true;
                //    N_of_feature1.Enabled = true;
                //    string query_countfeature1;
                //    query_countfeature1 = "SELECT count(*) FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature tf, HEMA_arabidopsis_thaliana_core_40_93_11.transcript t " +
                //    "WHERE tf.transcript_id = t.transcript_id AND tf.feature_id = '" + feature_id1 + "' AND tf.rank = " + cbo_first_feature_rank.Text + " AND t.biotype = 'protein_coding' ";
                //    int n = runQueryScalarValue(query_countfeature1);
                //    N_of_feature1.Text = (n).ToString();

                //}

                //MessageBox.Show(cbo_first_feature_rank.Text);
                //string query_countfeature1;
                //query_countfeature1 = "SELECT count(*) FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature tf, HEMA_arabidopsis_thaliana_core_40_93_11.transcript t " +
                //"WHERE tf.transcript_id = t.transcript_id AND tf.feature_id = '" + feature_id1 + "' AND tf.rank = " + cbo_first_feature_rank.Text + " AND t.biotype = 'protein_coding' ";
                //int n = runQueryScalarValue(query_countfeature1);
                //N_of_feature1.Text = (n).ToString();






            }
            if (rdo_two_feature.Checked) 
            {
                
                cbo_bp_flanking.Enabled = false;
                cbo_bp_flanking.SelectedIndex = -1;
                rdo_centre.Checked = false;
                rdo_left.Checked = false;
                rdo_right.Checked = false;
                cbo_bp_flanking.Enabled = false;
                //cbo_bp_flanking.Text = "";
                disable_chart1();
                
                cbo_second_feature.Enabled = true;
                if (cbo_first_feature.SelectedIndex!=-1&&cbo_second_feature.SelectedIndex!=-1&&cbo_second_feature_rank.SelectedIndex!=-1) 
                {
                    grp_context.Enabled = true;
                }
            }

        }

        private void sec_cbx_rank_Click(object sender, EventArgs e)
        {
            query_rank2 = "SELECT DISTINCT srp.rank FROM HEMA_arabidopsis_thaliana_core_40_93_11.transcript_feature srp WHERE feature_id ='" + feature_id2 + "' order by srp.rank; ";
            tb_rank2 = runQuery(query_rank2);
            tb_rank2.Columns[0].ColumnName = "Rank";
            cbo_second_feature_rank.DataSource = tb_rank2;
            cbo_second_feature_rank.DisplayMember = "Rank";
            cbo_second_feature_rank.ValueMember = "Rank";
        }

        private void rb_ana_lev2_CheckedChanged(object sender, EventArgs e)
        {
            rdo_pro_profile.Enabled = true;
            rdo_pro_profile.Checked = true;
            grp_features.Enabled = true;
            //pro_win.SelectedIndex = 2;
            //context_gbox.Enabled = true;
            //adding property_window (101,201,301,401,501) range for genome level
            BindingSource bs = new BindingSource();
            bs.DataSource = new List<string> { "11", "33", "101"};
            cbo_pro_win.DataSource = bs;
            cbo_pro_win.SelectedIndex = 2;
        }
    }
}
